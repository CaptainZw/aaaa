import React from 'react';
import logo from './logo.svg';

import Third from './components/Third'
import Second from './components/Second'

import './App.css';


const styleObj = {
  color:'green',
  fontSize:100,
  margin:0
}

function App() {
  // 这是一个方法
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        {/* 这是一个p标签 */}
        {/* <p style={{color:'red',fontSize:100}}> */}
        {/* <p style={styleObj}> */}
        <p className="testp">
          Edit <code>src/App.js</code> and save to reload666.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <hr />
        <Third name="尹志平" age={655}/>
        <Second name="张三丰" age={666} />
      </header>
    </div>
  )
}

export default App;
