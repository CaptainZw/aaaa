import React from 'react'

import './Second.css'

class Second extends React.Component {
    color = '白色'
    static address = '地球'

    constructor(){
        // 只要继承，就必须在第一句调用super方法，固定写法
        super()

        // 相当于Vue中的 data
        this.state = {
            name: '黄伟'
        }
    }
    
    render() {
        return (
            <>
                <div className="testp">
                    我还是一个好人...{this.state.name}---{this.color}---{Second.address}
                </div>
                <div>
                    对不起我是一个警察...{this.props.name} --- {this.props.age}
                </div>
            </>
        )
    }
}

export default Second