import React,{Component} from 'react'

export default class Counter extends Component{
    constructor(props){
        super()

        this.state = {
            count: props.initCount
        }
    }

    add = () => {
        // this.props.initCount ++

        this.setState({
            count: ++this.state.count
        }, () => {
            // 执行回调函数
            this.props.callback(this.state.count)
        })
    }

    render() {
        return <div>
            <span>{this.state.count}</span>
            <button onClick={this.add}>+1</button>
        </div>
    }
}
