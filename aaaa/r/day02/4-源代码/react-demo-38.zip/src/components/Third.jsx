import React from 'react'

// Props
function Third({name,age}){
    return <>
        <h1>我是函数式组件---{name}---{age}</h1>
    </>
}

export default Third