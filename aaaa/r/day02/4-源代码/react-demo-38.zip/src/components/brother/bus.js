import {EventEmitter} from 'events'

// 创建公共的bus
const bus = new EventEmitter()

export default bus