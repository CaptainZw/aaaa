import React, { Component } from 'react'

export default class FoodList extends Component {
    render() {
        return (
            <div>
                <ul>
                    <li>窝窝头</li>
                    <li>大闸蟹</li>
                    <li>6元麻辣烫</li>
                </ul>
            </div>
        )
    }
}
