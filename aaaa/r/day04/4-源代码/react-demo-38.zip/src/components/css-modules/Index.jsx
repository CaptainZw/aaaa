import React, { Component } from 'react'

import First from './First'
import Second from './Second'

export default class Index extends Component {
    render() {
        return (
            <div>
                <First />
                <Second />
            </div>
        )
    }
}
