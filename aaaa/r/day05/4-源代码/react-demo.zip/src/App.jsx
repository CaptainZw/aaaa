import React from "react";

// 默认导入
// import State from './components/State'


// 按需导入
import { State } from "./components/State";

// 导入子组件
import NoState from "./components/NoState";

import Counter from "./components/Counter";

import Brother1 from "./components/brother/Brother1";
import Brother2 from "./components/brother/Brother2";

import GrandPa from "./components/grandpa/GrandPa";

// import IF from './components/IF'

// import For from "./components/For";

// import Form from './components/Form'

import Uncontrolled from './components/Uncontrolled'

import Life from './components/Life'

// import Index from './components/router/Index'

// import Index from './components/router-nested/Index'

// import Index from './components/redux-counter/Index'

import Index from './components/react-redux-cart/Index'

// 定义组件
class App extends React.Component {
  state = {
    name:'小王',
    isShowLife:true
  }

  getValue = value => {
    console.log("---App---getValue---", value);
  };

  // jsx 语法 javascript xml
  render() {
    const {name,isShowLife} = this.state

    return (
      <div>
        {/* 你好<br/> */}
        {/* <NoState name="小明" age={82}/> */}
        {/* <State name="张三丰" age={666} sex="男" callback={this.getValue}/> */}

        {/* <Counter initCount={10} callback={this.getValue}/> */}
        {/* <Counter callback={this.getValue}/> */}

        {/* <Brother1 />
                <hr/>
                <Brother2 /> */}

        {/* <GrandPa /> */}

        {/* <IF /> */}

        {/* <For /> */}

        {/* <Form /> */}

        {/* <Uncontrolled /> */}
        {/* {
          isShowLife && <Life name={name}/>
        } */}

        <Index />
      </div>
    );
  }
}

export default App;
