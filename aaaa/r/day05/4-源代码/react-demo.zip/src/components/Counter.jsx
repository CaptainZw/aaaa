import React from 'react'

import PropTypes from 'prop-types'

class Counter extends React.Component{
    constructor(props){
        super()

        this.state = {
            count: props.initCount
        }
    }

    // static propTypes = {
    //     // 这个就是约定，你传递过来的 initCount 的值必须是一个数值类型
    //     initCount:PropTypes.number.isRequired,
    //     callback:PropTypes.func
    // }

    add = () => {
        // 不能更改父组件传递过来的值
        // this.props.initCount++

        // 这个setState是异步的
        this.setState({
            count: this.state.count + 1
        },() => {
            // 这个回调函数是当我们的setState执行完毕之后，才会执行这个回调函数
            this.props.callback(this.state.count)
        })
    }

    render(){
        return <div>
            我是子组件---{this.state.count}---<button onClick={this.add}>+</button>
        </div>
    }
}

Counter.defaultProps = {
    // 给父组件传递过来的initCount值设置为20【只有当父组件没有传递的时候，才会起作用】
    initCount:20
}

Counter.propTypes = {
    // 这个就是约定，你传递过来的 initCount 的值必须是一个数值类型
    // initCount:PropTypes.number.isRequired,
    initCount:PropTypes.number,
    callback:PropTypes.func
}

export default Counter