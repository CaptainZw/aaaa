import React, { Component } from 'react'

export default class For extends Component {
    state = {
        persons:[
            {id:1001,name:'李莫愁',age:1000},
            {id:1002,name:'成昆',age:666},
            {id:1003,name:'陈友谅',age:555},
            {id:1004,name:'欧阳锋',age:688}
        ]
    }

    render() {
        return (
            <div>
                <ul>
                    {this.state.persons.map(item => {
                        return <li key={item.id}>{item.name}---{item.age}</li>
                    })}
                </ul>
            </div>
        )
    }
}
