import React, { Component } from 'react'

export default class IF extends Component {
    state = {
        age:19
    }

    renderGreaterThan18 = () => {
        return <div style={{color:'green'}}>你可以结婚了 ---<button onClick={() => {this.setState({age:16})}}>返老还童</button></div>
    }

    renderLessThan18(){
        return <div style={{color:'red'}}>你还未成年，好好读书...</div>
    }

    render() {
        const {age} = this.state

        /** 条件渲染的第一种写法 */
        /**
        if (age > 18) {
            return <div style={{color:'green'}}>你可以结婚了 ---<button onClick={() => {this.setState({age:16})}}>返老还童</button></div>
        } else {
            return <div style={{color:'red'}}>你还未成年，好好读书...</div>
            
        }
         */

         /** 
        return <div>
            {
                age > 18 ? this.renderGreaterThan18() : this.renderLessThan18()
            }
         </div>
         */

        return <div>
            {age > 18 && this.renderGreaterThan18()}

            {age < 18 && this.renderLessThan18()}
        </div>
    }
}
