import React, { Component } from 'react';

class Life extends Component {
    constructor(){
        super()

        this.state = {
            age:18
        }

        console.log('----1----')
    }

    // componentWillMount(){
    //     console.log('---2---')
    // }

    UNSAFE_componentWillMount(){
            console.log('---2---')
        }

    changeAge = () => {
        this.setState({
            age:20
        })
    }

    render() {
        console.log('---3---render---')
        return (
            <div>
                <span ref="spanRef">年龄是 {this.state.age}</span><br/>
                <span>{this.props.name}</span><br/>
                <button onClick={this.changeAge}>改变年龄</button>
            </div>
        );
    }

    componentDidMount(){
        console.log('---4---',this.refs.spanRef)
    }

    /*** 运行阶段 start ***/
    // componentWillReceiveProps(props){
    //     console.log('---componentWillReceiveProps---',props)
    // }

    UNSAFE_componentWillReceiveProps(props){
            console.log('---componentWillReceiveProps---',props)
        }

    UNSAFE_componentWillUpdate(nextProps, nextState){
        console.log("---UNSAFE_componentWillUpdate---")
    }

    shouldComponentUpdate(){
        console.log('---shouldComponentUpdate---')

        return true
    }

    // componentWillUpdate(){
    //     console.log('--componentWillUpdate--')
    // }

    componentDidUpdate(){
        console.log('--componentDidUpdate--',this.refs.spanRef)
    }

    /*** 运行阶段 end ***/

    componentWillUnmount(){
        console.log('--componentWillUnmount--')
    }
}

export default Life;