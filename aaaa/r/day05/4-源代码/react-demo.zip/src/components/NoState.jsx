import React from 'react'

// import './NoState.module.css'

// 下面是 css_modules 的实现
import styles from  './NoState.module.css'
// console.log(styles)

// 使用函数创建的是无状态组件
// function NoState(props){
function NoState({name,age}){
    // console.log(props)
    // return <div className="second">我是一个无状态组件</div>

    // return <div className={styles.second}>我是一个无状态组件---{props.name}----{props.age}</div>

    return <div className={styles.second}>我是一个无状态组件---{name}--{age}</div>

    // return React.createElement('p',null,'你是一个好人')
}

export default NoState