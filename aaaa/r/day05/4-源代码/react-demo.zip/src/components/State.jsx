import React from 'react'

// import './State.module.css'

// CSS Module 的方式
import styles from './State.module.css'
// console.log(styles)

class State extends React.Component{
    id = 222

    constructor(){
        super()

        // 状态 === 数据
        this.state = {
            name:'小明',
            age:30
        }

        this.clickMe2 = this.clickMe2.bind(this)
    }

   // state 的简化写法
//    state = {
//         name:'小红',
//         age:20
//     }

    // styles = {
    //     color:'green',
    //     fontSize:'30px'
    // }

    clickMe(){
        console.log("---clickMe---",this)

        // 这样改，不能够更新视图
        // this.state.name = "大明"

        // console.log(this.state)

        this.setState({
            name:'大明'
        })

        // 以下做法不可取
        // this.props.age++
    }

    clickMe2(){
        this.setState({
            name:'大大明'
        })
    }

    clickMe3 = () => {
        this.setState({
            name:'大大大明'
        })
    }

    mouseMove = () => {
        console.log('---mouseMove--',this)
    }

    sendValueToParent = () => {
        // console.log(this.props)
        this.props.callback('你是一个好人')
    }

    /**
     * 在有状态组件中，如果我们要想显示内容，必须实现render函数
     */
    render(){
        const {name,sex} = this.props
        return <>
            {/* <div style={{color:'red',fontSize:'30px'}}>有状态组件1---{this.state.name}---{this.id}</div> */}
            {/* <div style={this.styles}>有状态组件1---{this.state.name}---{this.id}</div> */}
            <div className={styles.second}>有状态组件--{this.state.name}---{this.state.age}</div>
            <div>父组件传递过来的值，不能更改 {name}---{sex}</div>
            <button onClick={this.clickMe.bind(this)}>更改自己的name的值</button>
            <button onClick={this.clickMe2}>更改自己的name的值2</button>

            {/* 下面这种方式是比较推荐的 */}
            <button onClick={this.clickMe3}>更改自己的name的值3</button>

            <div onMouseMove={this.mouseMove}>移动到上面试试啊</div>
            <div>
                <button onClick={this.sendValueToParent}>传值给父组件，约定传递一个123的字符串</button>
            </div>

            {/* <div className="second">有状态组件2---{this.state.age}</div> */}
        </>
    }
}

// 默认导出
// export default State

// 按需导出
export {State}