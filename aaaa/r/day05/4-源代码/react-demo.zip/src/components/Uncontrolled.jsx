import React, { Component } from 'react'

export default class Uncontrolled extends Component {
    constructor(){
        super()

        // 最新的写法
        this.inputRef = React.createRef()
    }

    // 这也是React生命周期钩子之一，代表视图渲染完毕
    componentDidMount(){
        // document.getElementById('inputId').focus()

        // console.log(this.refs.inputRef)

        // this.refs.inputRef.focus()

        // console.log(this.inputRef.current)

        this.inputRef.current.focus()

        // console.log(this.inputRef.current.value)
    }

    render() {
        return (
            <div>
                {/* <input id="inputId" type="text"/> */}

                {/* 之前的写法 */}
                {/* <input ref="inputRef" type="text"/> */}


                <input ref={this.inputRef} type="text"/>
            </div>
        )
    }
}
