import React, { Component } from 'react'

import bus from './bus'

export default class Brother1 extends Component {
    sendValueToBrother2 = () => {
        // bus.emit('myevent','你是一个好人...')
        bus.emit('myevent',[{id:1001,name:'张无忌'},{id:1002,name:'赵敏'}])
    }

    render() {
        return (
            <div>
                我是兄弟1---<button onClick={this.sendValueToBrother2}>传递值给兄弟2</button>
            </div>
        )
    }
}
