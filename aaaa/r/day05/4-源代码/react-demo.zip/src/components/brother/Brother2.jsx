import React, { Component } from 'react'

import bus from './bus'

export default class Brother2 extends Component {
    // 生命周期钩子之一，代表视图内容即将要挂载，它只会执行一次
    componentWillMount(){
        bus.on('myevent',data => {
            console.log('---我是兄弟组件2---')
            console.log(data)
        })
    }

    render() {
        return (
            <div>
                我是兄弟2
            </div>
        )
    }
}
