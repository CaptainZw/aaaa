import {EventEmitter} from 'events'

const bus = new EventEmitter()

export default bus