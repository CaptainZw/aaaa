import React, { Component } from 'react'

import {Provider} from './context'

import Son from './Son'

export default class GrandPa extends Component {
    constructor(){
        super()

        this.state = {
            theme:'red'
        }
    }

    changeBlue = () => {
        this.setState({
            theme:'blue'
        })
    }

    changeRed = () => {
        this.setState({
            theme:'red'
        })
    }

    render() {
        const {theme} = this.state
        return (
            <Provider value={{ themeColor: theme }}>   
                <div style={{color:theme}}>
                    我是爷爷--<button onClick={this.changeBlue}>蓝色</button>&nbsp;&nbsp;&nbsp;<button onClick={this.changeRed}>红色</button><br/>

                    <Son />
                </div>
            </Provider>
        )
    }
}
