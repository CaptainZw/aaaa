import React, { Component } from 'react'

import {Consumer} from './context'

export default class GrandSon extends Component {
    render() {
        return (
            <Consumer>
                {value => (<div style={{color:value.themeColor}}>
                    孙子---{value.themeColor}
                </div>)}
            </Consumer>
        )
    }
}
