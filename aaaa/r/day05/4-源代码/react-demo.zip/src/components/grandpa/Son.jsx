import React, { Component } from 'react'

import GrandSon from './GrandSon'

import {Consumer} from './context'

export default class Son extends Component {
    render() {
        return (
            <Consumer>
                {data => {
                    return <div style={{color:data.themeColor}}>
                            我是儿子组件---{data.themeColor}<br/>
                            <GrandSon />
                    </div>
                }}
            </Consumer>
        )
    }
}
