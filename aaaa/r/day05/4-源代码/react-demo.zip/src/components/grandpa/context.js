import React from 'react'

/**
 * Provider 提供者 爷爷组件
 * Consumer 消费者 爷爷的子孙都是消费者
 */
const {Provider,Consumer} = React.createContext()

// 按需导出
export {Provider,Consumer}