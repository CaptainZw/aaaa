import React, { Component } from 'react'

import store from './store/index'

import {Table,InputNumber,Button,Modal} from 'antd'

import {updateGoods,asyncDeleteGoods} from './store/actionCreators'

const { confirm } = Modal;

export default class Cart extends Component {
    state = {
        goodsList: [],
        totalPrice:0
    }

    componentDidMount(){
        // 第一次取出来展示
        this.getNewData()

        // 仓库中的数据发生了改变
        store.subscribe(() => {
            this.getNewData()
        })
    }

    getNewData(){
        const goodsList = store.getState()

        goodsList.forEach(item => {
            item.key = item.id
        })

        let total = 0
        goodsList.forEach(item => {
            total += item.num * item.price
        })

        this.setState({
            goodsList,
            totalPrice:total
        })
    }

    onChange = (id,num) => {
        // console.log(id,number)

        // 触发修改商品数量的action
        store.dispatch(updateGoods({id,num}))
    }

    // 删除
    deleteGoods = id => {
        confirm({
            title: '提示',
            content: '确定删除该记录吗?',
            okText: '是',
            okType: 'danger',
            cancelText: '否',
            onOk() {
              console.log('OK');
              // 去删除仓库中的数据
              store.dispatch(asyncDeleteGoods(id))
            },
            onCancel() {
              console.log('Cancel');
            },
          });
    }

    columns = [
        {
            title: '名字',
            dataIndex: 'name',
            key: 'name'
        },
        {
            title: '图片',
            dataIndex: 'url',
            key: 'url',
            render:url => {
                return <img style={{width:100,height:100}} src={url} />
            }
        },
        {
            title: '数量',
            key: 'num',
            render: ({id,num}) => {
                return <InputNumber min={1} defaultValue={num} onChange={(value) => this.onChange(id,value)} />
            }
        },
        {
            title: '单价',
            dataIndex: 'price',
            key: 'price'
        },
        {
            title: '总价',
            key: 'name1',
            render: ({num,price}) => {
                return <span>{num * price}</span>
            }
        },
        {
            title: '操作',
            key: 'name2',
            dataIndex:'id',
            render:(id) => {
                return <Button type="danger" onClick={() => this.deleteGoods(id)}>删 除</Button>
            }
        }
    ]

    render() {
        const {goodsList,totalPrice} = this.state
        return (
            <div>
                {/* 表格 */}
                <Table columns={this.columns} dataSource={goodsList} pagination={false}/>
                {/* 总价 */}
                <p>总价：{totalPrice}</p>
                <Button type="primary" style={{color:'white',backgroundColor:'#67c23a'}}>去结算</Button>
            </div>
        )
    }
}
