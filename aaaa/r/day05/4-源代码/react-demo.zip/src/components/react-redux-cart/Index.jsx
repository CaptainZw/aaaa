import React, { Component } from 'react';

import styles from './Index.module.css' // style-loader & css-loader

import {HashRouter as Router,Link,Route,Switch,Redirect} from 'react-router-dom'

// 导入子组件
import GoodsList from './GoodsList'
import Cart from './Cart'

/**
 * 建立组件和redux的关系
 */
import {connect} from 'react-redux'

class Index extends Component {
    componentDidMount(){
        // 监听页面关闭事件
        window.onbeforeunload = () => {
            localStorage.setItem('SHOPCART',JSON.stringify(store.getState()))
        }
    }

    render() {
        const {count} = this.props
        return (
            <Router>
                <div>
                    <h2 className={styles.title}>黑马买买买-商城
                        <p>
                            <Link to="/goodslist">商品列表</Link>&nbsp;&nbsp;
                            <Link to="/cart">购物车{count > 0 && <span>（{count}）</span>}</Link>
                        </p>
                    </h2>
                    <div className={styles.indexContainer}>
                        <Switch>
                            <Route path="/goodslist" component={GoodsList}/>
                            <Route path="/cart" component={Cart}/>
                            <Redirect exact from="/" to="/goodslist"/>
                        </Switch>
                    </div>
                </div>
            </Router>
        );
    }
}

/**
 * 
 * @param {*} state 代表着仓库
 */
const mapStateToProps = (state) => {
    // 这个就是商品列表
    console.log("111111111111")
    console.log(state)
    
    function getNewData(){
        let totalCount = 0
        state.forEach(item => {
            totalCount += item.num
        })

        return totalCount
    }

    // 作为 Index的props
    return {
        count: getNewData()
    }
}

export default connect(mapStateToProps,null)(Index);