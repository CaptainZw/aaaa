import {ADD_GOODS,UPDATE_GOODS,DELETE_GOODS} from './actionTypes'

export const addGoods = goods => {
    return {
        type: ADD_GOODS,
        goods
    }
}

export const updateGoods = goods => {
    return {
        type: UPDATE_GOODS,
        goods
    }
}

export const deleteGoods = id => {
    return {
        type: DELETE_GOODS,
        id
    }
}

export const asyncDeleteGoods = id => {
    return dispatch => {
        // setTimeout(() => {
        //     dispatch(deleteGoods(id))
        // }, 2000);
        setTimeout(() => {
            dispatch(deleteGoods(id))
        }, 0);
    }
}