export const ADD_GOODS = 'ADD_GOODS'

export const UPDATE_GOODS = 'UPDATE_GOODS'

export const DELETE_GOODS = 'DELETE_GOODS'