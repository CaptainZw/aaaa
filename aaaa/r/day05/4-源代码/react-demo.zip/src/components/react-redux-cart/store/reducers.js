import {ADD_GOODS,UPDATE_GOODS,DELETE_GOODS} from './actionTypes'

/**
 * action === {type:'ADD_GOODS',goods:{id:1001,num:1,...}}
 */

 const goodsList = JSON.parse(localStorage.getItem('SHOPCART') || '[]')

export default (state = goodsList,action) => {
    // console.log(action)
    switch (action.type) {
        case ADD_GOODS:
            // 建议把上一次的数据，进行深拷贝之后再继续操作
            const ADDLIST = JSON.parse(JSON.stringify(state))

            // 用到了es6的find方法
            const oldAddGoods = ADDLIST.find(item => item.id === action.goods.id)

            if (oldAddGoods) {
                oldAddGoods.num += 1
            } else {
                ADDLIST.push(action.goods)
            }
            return ADDLIST

        case UPDATE_GOODS:
             // 建议把上一次的数据，进行深拷贝之后再继续操作
             const UPDATELIST = JSON.parse(JSON.stringify(state))
             
             const oldUpdateGoods = UPDATELIST.find(item => item.id === action.goods.id)
             oldUpdateGoods.num = action.goods.num

            return UPDATELIST

        case DELETE_GOODS:
            // 建议把上一次的数据，进行深拷贝之后再继续操作
            const DELETELIST = JSON.parse(JSON.stringify(state))
            const deleteIndex = DELETELIST.findIndex(item => item.id === action.id)
            DELETELIST.splice(deleteIndex,1)
            return DELETELIST

        default:
            return state
    }
}