import React, { Component } from 'react';

import styles from './Index.module.css' // style-loader & css-loader

import {HashRouter as Router,Link,Route,Switch,Redirect} from 'react-router-dom'

// 导入子组件
import GoodsList from './GoodsList'
import Cart from './Cart'
import store from './store';

class Index extends Component {
    state = {
        count: 0
    }

    componentDidMount(){
        // 第一次
        this.getNewData()

        // 当仓库中的数据发生了改变
        store.subscribe(() => {
           this.getNewData()
        })

        // 监听页面关闭事件
        window.onbeforeunload = () => {
            localStorage.setItem('SHOPCART',JSON.stringify(store.getState()))
        }
    }

    getNewData(){
        let totalCount = 0
        store.getState().forEach(item => {
            totalCount += item.num
        })

        this.setState({
            count: totalCount
        })
    }

    render() {
        const {count} = this.state
        return (
            <Router>
                <div>
                    <h2 className={styles.title}>黑马买买买-商城
                        <p>
                            <Link to="/goodslist">商品列表</Link>&nbsp;&nbsp;
                            <Link to="/cart">购物车{count > 0 && <span>（{count}）</span>}</Link>
                        </p>
                    </h2>
                    <div className={styles.indexContainer}>
                        <Switch>
                            <Route path="/goodslist" component={GoodsList}/>
                            <Route path="/cart" component={Cart}/>
                            <Redirect exact from="/" to="/goodslist"/>
                        </Switch>
                    </div>
                </div>
            </Router>
        );
    }
}

export default Index;