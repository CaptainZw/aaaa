import React, { Component } from 'react';

import store from './store/index'

// 按需导入需要的action creator
import {add} from './store/actionCreators'

class Add extends Component {
    add = () => {
        // 触发新增的动作
        // store.dispatch({
        //     type:'add'
        // })

        store.dispatch(add())
    }

    render() {
        return (
            <div>
                <button onClick={this.add}>+</button>
            </div>
        );
    }
}

export default Add;