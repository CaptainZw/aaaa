import React, { Component } from 'react';

import Add from './Add'
import Minus from './Minus'

// 导入仓库
import store from './store/index'

class Index extends Component {
    constructor(){
        super()

        this.state = {
            count:store.getState()
        }
    }

    componentDidMount(){
        store.subscribe(() => {
            // console.log("111111111111111")
            
            // 当仓库中的值发生了改变之后，重新从仓库中获取值，赋值给模型
            this.setState({
                count:store.getState()
            })
        })
    }

    render() {
        console.log('---Index-----render------')
        return (
            <div>
                count is {this.state.count}<br/><br/><br/>

                <div style={{display:'flex'}}>
                    <Minus />&nbsp;&nbsp;&nbsp;
                    <Add />
                </div>
            </div>
        );
    }
}

export default Index;