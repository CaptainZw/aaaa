import React, { Component } from 'react';

import store from './store/index'

import {minus,asyncMinus} from './store/actionCreators'

class Minux extends Component {
    minus = () => {
        // store.dispatch({
        //     type:'minus'
        // })

        // store.dispatch(minus())

        // 触发 异步的 action
        store.dispatch(asyncMinus())
    }

    render() {
        return (
            <div>
                <button onClick={this.minus}>-</button>
            </div>
        );
    }
}

export default Minux;