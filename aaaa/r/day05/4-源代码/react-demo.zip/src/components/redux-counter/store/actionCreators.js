/**
 * 都是导出去的一些函数，函数内部返回的就是action对象
 */

 import {ADD,MINUS} from './actionTypes'

 // 该函数返回 action 对象就称之为 actionCreator
 export const add = () => {
     // 返回的就是action对象
     return {
        type:ADD
     }
 }

 export const minus = () => {
     return {
         type: MINUS
     }
 }

 export const asyncMinus = () => {
     return dispatch => {
         // 模拟异步操作
         setTimeout(() => {
             // 异步操作执行完之后，调用同步的action 触发动作
            dispatch(minus())
         }, 2000);
     }
 }