// 按需导出
export const ADD = 'ADD'

export const MINUS = 'MINUS'

// 上面的一句话，相当于下面的两句话
// const ADD = 'ADD'
// export {ADD}