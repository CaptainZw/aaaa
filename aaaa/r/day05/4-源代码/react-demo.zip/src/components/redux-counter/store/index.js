import {createStore,applyMiddleware,compose} from 'redux'

// 导入thunk 实现异步的action
import thunk from 'redux-thunk'

// 导入reducers
import reducers from './reducers'

// 这个是给调试工具使用的 https://github.com/zalmoxisus/redux-devtools-extension#12-advanced-store-setup
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose

// 创建仓库
const store = createStore(reducers, composeEnhancers(
    applyMiddleware(thunk)
))

// 导出仓库
export default store