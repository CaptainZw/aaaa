/**
 * state 就是我们仓库中要操作的值，我们可以给它设置一个初始值
 * 
 * action 它是一个对象，里面有一个属性叫做 type
 */

import {ADD,MINUS} from './actionTypes'

export default (state = 0,action) => {
    // console.log(action)
    switch (action.type) {
        case ADD:
            return state + 1

        case MINUS:
            return state - 1
    
        default:
            return state
    }
}