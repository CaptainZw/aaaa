import React, { Component } from 'react';

import styles from './Layout.module.css'

import {Link,Route,Switch,Redirect} from 'react-router-dom'

class User extends Component{
    render(){
        return <div>我是用户管理组件</div>
    }
}

class Layout extends Component {
    render() {
        return (
            <div className={styles.layout}>
                <div className={styles.left}>
                    <Link to="/layout/user">用户管理</Link><br/><br/>
                    <Link to="/layout/right">权限管理</Link>
                </div>

                <div className={styles.right}>
                    <Switch>
                        <Route path="/layout/user" component={User}/>
                        <Route path="/layout/right" render = {() => { return <div>权限管理组件</div> }}/>

                        <Redirect exact from="/layout" to="/layout/user"/>
                    </Switch>
                </div>
            </div>
        );
    }
}

export default Layout;