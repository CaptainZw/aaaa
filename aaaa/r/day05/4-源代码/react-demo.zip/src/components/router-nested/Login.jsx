import React, { Component } from 'react'

import styles from './Login.module.css'

export default class Login extends Component {
    state = {
        username:'',
        password:''
    }

    change = e => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    login = () => {
        const {username,password} = this.state

        if (username === 'admin' && password === '123'){
            // 编程式导航跳转到布局页面
            this.props.history.push('/layout')
        } else {
            alert('用户名或是密码失败')
        }
    }

    render() {
        const {username,password} = this.state
        return (
            <div className={styles.loginContainer}>
                用户名:<input value={username} name="username" onChange={this.change} type="text"/><br/>
                密码:<input value={password} name="password" onChange={this.change} type="password" /><br/>
                <button onClick={this.login}>登录</button>
            </div>
        )
    }
}
