import React, { Component } from 'react'

export default class GoodsList extends Component {
    render() {
        return (
            <div>
                <ul>
                    <li>隆江猪脚饭</li>
                    <li>湖南木桶饭</li>
                    <li>兰州拉面</li>
                </ul>
            </div>
        )
    }
}
