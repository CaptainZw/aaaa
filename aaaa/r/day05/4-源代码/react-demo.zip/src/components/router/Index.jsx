import React, { Component } from 'react'

import {HashRouter as Router,Link,Route,Switch,Redirect} from 'react-router-dom'
// import {BrowserRouter as Router,Link,Route} from 'react-router-dom'

import GoodsList from './GoodsList'
import NewsList from './NewsList'
import NewsDetail from './NewsDetail'
import NotFound from './NotFound'

export default class Index extends Component {
    render() {
        return (
            <Router>
                <div>
                    路由演示<br/>
                    <Link to="/goodslist">商品列表</Link>&nbsp;&nbsp;
                    <Link to="/newslist">新闻列表</Link><br/>

                    {/* 设置路由规则 & 占位符(router-view) */}
                    {/* 默认情况下，我们的路由匹配是模糊匹配，如果给我们的规则加上了 exact 代表，我们的规则一定要和 path 相等才能匹配上 */}
                    {/* <Route path="/" exact component={GoodsList}/> */}

                    <Switch>
                        <Route path="/goodslist" component={GoodsList}/>
                        <Route path="/newslist" component={NewsList}/>
                        {/* query传参用下面的 */}
                        {/* <Route path="/newsdetail" component={NewsDetail}/> */}

                        {/* params传参 */}
                        <Route path="/newsdetail/:newsId" component={NewsDetail}/>

                        <Redirect exact from="/" to="/goodslist"/>

                        {/* 404一定要放在所有路由规则的最后面 */}
                        <Route component={NotFound}/>
                    </Switch>
                </div>
            </Router>
        )
    }
}
