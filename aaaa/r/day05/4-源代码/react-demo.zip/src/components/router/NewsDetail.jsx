import React, { Component } from 'react'

export default class NewsDetail extends Component {
    componentDidMount(){
        /** query参数处理 */
        // search ===> ?newsId=1003
        // var searchParams = new URLSearchParams(this.props.location.search)

        // console.log(searchParams.get('newsId'))

        console.log(this.props.match.params.newsId)
    }

    render() {
        // console.log(this.props)
        return (
            <div>
              我是新闻详情组件  
            </div>
        )
    }
}
