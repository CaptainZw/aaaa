import React, { Component } from "react";

import { Link } from "react-router-dom";

export default class NewsList extends Component {
  render() {
    return (
      <div>
        <ul>
          <li>国庆大阅兵</li>
          {/* query传参 */}
          {/* <li>
            <Link to="/newsdetail?newsId=1001">吴亦凡恋情疑曝光</Link>
          </li>
          <li>
            <Link to="/newsdetail?newsId=1003">深圳楼房倒塌，一夜之间暴涨60万</Link>
          </li> */}

          {/* params传参 */}
          <li>
            <Link to="/newsdetail/1001">吴亦凡恋情疑曝光</Link>
          </li>
          <li>
            <Link to="/newsdetail/1003">
              深圳楼房倒塌，一夜之间暴涨60万
            </Link>
          </li>
        </ul>
      </div>
    );
  }

  // componentWillUnmount(){
  //     console.log('---NewsList---componentWillUnmount')
  // }
}
