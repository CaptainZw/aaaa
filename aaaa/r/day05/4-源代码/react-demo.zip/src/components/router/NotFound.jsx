import React, { Component } from 'react'

// 以模块的方式加载图片
import img from '../../static/images/404.png'
// console.log(img)

export default class NotFound extends Component {
    render() {
        return (
            <div>
                {/* <img src="../../static/images/404.png" alt=""/> */}
                <img src={img} alt=""/>
            </div>
        )
    }
}
