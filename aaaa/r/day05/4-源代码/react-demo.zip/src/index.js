// 导包
import React from 'react'
import ReactDOM from 'react-dom'

// 导入根组件
import App from './App'

// 导入仓库
import {Provider} from 'react-redux'
import store from './components/react-redux-cart/store'

// 渲染根组件，渲染到id=root的div中去
ReactDOM.render(<Provider store={store}><App /></Provider>,document.getElementById('root'))