const HtmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  mode: "development", // 开发模式，它不会压缩js代码，方便调试
  // 打包的入口
  entry: "./src/index.js",
  // 开发阶段不需要配置 output

  // 下面这个步骤多
  // 使用loader解析jsx，用到了babel-loader https://babeljs.io/
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: /(node_modules|bower_components)/, // 排除哪些不适用babel转换
        use: {
          loader: "babel-loader"
          // 下面的配置，还可以单独提取出去(在项目根目录，创建.babelrc)，二者选择其一即可
          //   options: {
          //     presets: ['@babel/preset-react']
          //   }
        }
      },
      {
        test: /\.css$/,
        exclude: /node_modules/,
        use: [{
          loader:'style-loader'
        }, {
          loader:'css-loader',
          options:{
            modules:{
              localIdentName: '[name]_[local]_[hash:base64:5]'
            }
          }
        }]
      },
      {//antd样式处理
        test:/\.css$/,
        exclude:/src/,
        use:[
            { loader: "style-loader",},
            {
                loader: "css-loader",
                options:{
                    importLoaders:1
                }
            }
        ]
      },
      {
        test: /\.(png|jpg|gif)$/i,
        use: [
          {
            loader: 'url-loader',
            // options: {
            //   limit: 8192 //如果我们的图片大于 8192字节，就把图片单独打包出来，否则就以base64打包到js中
            // }
          }
        ]
      },
      {
        test: /\.(ttf|woff)$/i,
        use: [
          {
            loader: 'url-loader',
            // options: {
            //   limit: 8192 //如果我们的图片大于 8192字节，就把图片单独打包出来，否则就以base64打包到js中
            // }
          }
        ]
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      // 将来在运行的时候，我们运行的那个index.html就是参照 public/index.html生成的
      template:'./public/index.html'
    })
  ],
  // 给我们导入的文件加上拓展名，防止找不到文件
  resolve: {
    extensions: ['.jsx', '.js', '.json']
  },
  devServer: {
		// history模式下的url会请求到服务器端，但是服务器端并没有这一个资源文件，就会返回404，所以需要配置这一项
		historyApiFallback: {
			index: '/index.html' //与output的publicPath有关(HTMLplugin生成的html默认为index.html)
		}
	}
};
