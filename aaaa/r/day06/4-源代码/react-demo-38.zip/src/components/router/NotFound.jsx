import React, { Component } from 'react'

export default class NotFound extends Component {
    render() {
        return (
            <div>
                <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1570444188763&di=6284b48e78579379a9bd411b32a98f11&imgtype=0&src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01565959e6bcfda80121bea5beef4c.jpg%401280w_1l_2o_100sh.jpg" alt=""/>
            </div>
        )
    }
}
